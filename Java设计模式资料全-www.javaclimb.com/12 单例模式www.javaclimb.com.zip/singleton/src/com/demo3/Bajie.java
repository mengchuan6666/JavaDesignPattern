package com.demo3;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Bajie extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3838175884560920622L;
	private static Bajie instance = new Bajie();

	private Bajie() {
		JLabel l1 = new JLabel(new ImageIcon("src/Bajie.jpg"));
		this.add(l1);
	}

	public static Bajie getInstance() {
		return instance;
	}
}