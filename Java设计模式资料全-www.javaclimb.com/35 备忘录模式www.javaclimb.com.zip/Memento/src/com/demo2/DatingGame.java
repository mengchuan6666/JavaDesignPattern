package com.demo2;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class DatingGame {
	public static void main(String[] args) {
		new DatingGameWin();
	}
}

//�ͻ�������
class DatingGameWin extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	JPanel CenterJP, EastJP;
	JRadioButton girl1, girl2, girl3, girl4;
	JButton button1, button2;
	String FileName;
	JLabel g;
	You you;
	GirlStack girls;

	DatingGameWin() {
		super("���ñ���¼ģʽ���������Ϸ");
		you = new You();
		girls = new GirlStack();
		this.setBounds(0, 0, 900, 380);
		this.setResizable(false);
		FileName = "src/com/demo2/Photo/�Ĵ���Ů.jpg";
		g = new JLabel(new ImageIcon(FileName), JLabel.CENTER);
		CenterJP = new JPanel();
		CenterJP.setLayout(new GridLayout(1, 4));
		CenterJP.setBorder(BorderFactory.createTitledBorder("�Ĵ���Ů���£�"));
		CenterJP.add(g);
		this.add("Center", CenterJP);
		EastJP = new JPanel();
		EastJP.setLayout(new GridLayout(1, 1));
		EastJP.setBorder(BorderFactory.createTitledBorder("��ѡ��İ����ǣ�"));
		this.add("East", EastJP);
		JPanel SouthJP = new JPanel();
		JLabel info = new JLabel("�Ĵ���Ů�С���������֮�ݡ������߻�֮ò������ѡ��˭��");
		girl1 = new JRadioButton("��ʩ", true);
		girl2 = new JRadioButton("����");
		girl3 = new JRadioButton("���Ѿ�");
		girl4 = new JRadioButton("����");
		button1 = new JButton("ȷ��");
		button2 = new JButton("����");
		ButtonGroup group = new ButtonGroup();
		group.add(girl1);
		group.add(girl2);
		group.add(girl3);
		group.add(girl4);
		SouthJP.add(info);
		SouthJP.add(girl1);
		SouthJP.add(girl2);
		SouthJP.add(girl3);
		SouthJP.add(girl4);
		SouthJP.add(button1);
		SouthJP.add(button2);
		button1.addActionListener(this);
		button2.addActionListener(this);
		this.add("South", SouthJP);
		showPicture("�հ�");
		you.setWife("�հ�");
		girls.push(you.createMemento()); //����״̬
	}

	//��ʾͼƬ
	void showPicture(String name) {
		EastJP.removeAll(); //����������
		EastJP.repaint(); //ˢ����Ļ
		you.setWife(name);
		FileName = "src/com/demo2/Photo/" + name + ".jpg";
		g = new JLabel(new ImageIcon(FileName), JLabel.CENTER);
		EastJP.add(g);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		boolean ok = false;
		if (e.getSource() == button1) {
			ok = girls.push(you.createMemento()); //����״̬  
			if (ok && girl1.isSelected()) {
				showPicture("��ʩ");
			} else if (ok && girl2.isSelected()) {
				showPicture("����");
			} else if (ok && girl3.isSelected()) {
				showPicture("���Ѿ�");
			} else if (ok && girl4.isSelected()) {
				showPicture("����");
			}
		} else if (e.getSource() == button2) {
			you.restoreMemento(girls.pop()); //�ָ�״̬
			showPicture(you.getWife());
		}
	}
}

//����¼����Ů
class Girl {
	private String name;

	public Girl(String name) {
		this.name = name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}

//�����ˣ���
class You {
	private String wifeName; //����

	public void setWife(String name) {
		wifeName = name;
	}

	public String getWife() {
		return wifeName;
	}

	public Girl createMemento() {
		return new Girl(wifeName);
	}

	public void restoreMemento(Girl p) {
		setWife(p.getName());
	}
}

//�����ߣ���Ůջ
class GirlStack {
	private Girl girl[];
	private int top;

	GirlStack() {
		girl = new Girl[5];
		top = -1;
	}

	public boolean push(Girl p) {
		if (top >= 4) {
			System.out.println("��̫�����ˣ�������ȥ�ģ�");
			return false;
		} else {
			girl[++top] = p;
			return true;
		}
	}

	public Girl pop() {
		if (top <= 0) {
			System.out.println("��Ůջ���ˣ�");
			return girl[0];
		} else
			return girl[top--];
	}
}