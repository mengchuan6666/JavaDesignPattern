package com.demo2;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class BagManage {
	public static void main(String[] args) {
		Color color = (Color) ReadXML.getObject("color");
		Bag bag = (Bag) ReadXML.getObject("bag");
		bag.setColor(color);
		Size size = (Size) ReadXML.getObject("size");
		bag.setSize(size);
		String name = bag.getName();
		show(name);
	}

	public static void show(String name) {
		JFrame jf = new JFrame("�Ž�ģʽ����");
		Container contentPane = jf.getContentPane();
		JPanel p = new JPanel();
		JLabel l = new JLabel(new ImageIcon("src/com/demo2/" + name + ".jpg"));
		p.setLayout(new GridLayout(1, 1));
		p.setBorder(BorderFactory.createTitledBorder("ŮʿƤ��"));
		p.add(l);
		contentPane.add(p, BorderLayout.CENTER);
		jf.pack();
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

//ʵ�ֻ���ɫ����ɫ
interface Color {
	String getColor();
}

//����ʵ�ֻ���ɫ����ɫ
class Yellow implements Color {
	public String getColor() {
		return "yellow";
	}
}

//����ʵ�ֻ���ɫ����ɫ
class Red implements Color {
	public String getColor() {
		return "red";
	}
}

//ʵ�ֻ���ɫ����С
interface Size{
	String getSize();
}

//����ʵ�ֻ���ɫ����
class Big implements Size{
	public String getSize() {
		return "big";
	}	
}

//����ʵ�ֻ���ɫ����
class Middle implements Size{
	public String getSize() {
		return "middle";
	}	
}

//����ʵ�ֻ���ɫ��С
class Small implements Size{
	public String getSize() {
		return "small";
	}	
}

//���󻯽�ɫ����
abstract class Bag {
	protected Color color;
	
	protected Size size;

	public void setColor(Color color) {
		this.color = color;
	}
	
	public void setSize(Size size) {
		this.size = size;
	}
	
	public abstract String getName();
}

//��չ���󻯽�ɫ�����
class HandBag extends Bag {
	public String getName() {
		System.out.println(color.getColor() + "HandBag"+"  �ͺţ�"+size.getSize());
		return color.getColor() + "HandBag";
	}
}

//��չ���󻯽�ɫ��Ǯ��
class Wallet extends Bag {
	public String getName() {
		System.out.println(color.getColor() + "HandBag"+"  �ͺţ�"+size.getSize());
		return color.getColor() + "Wallet";
	}
}