package com.demo2;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SunWukong extends JPanel implements Cloneable {
	private static final long serialVersionUID = -6281368292527379739L;

	public SunWukong() {
		JLabel l1 = new JLabel(new ImageIcon("src/Wukong.jpg"));
		this.add(l1);
	}

	public Object clone() {
		SunWukong w = null;
		try {
			w = (SunWukong) super.clone();
		} catch (CloneNotSupportedException e) {
			System.out.println("�������ʧ��!");
		}
		return w;
	}
}