package com.demo3;

public class Citation implements Cloneable {
	String name;
	String info;
	String college;

	public Citation(String name, String info, String college) {
		this.name = name;
		this.info = info;
		this.college = college;
		System.out.println("��״�����ɹ���");
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return (this.name);
	}

	public void display() {
		System.out.println(name + info + college);
	}

	public Object clone() throws CloneNotSupportedException {
		System.out.println("��״�����ɹ���");
		return (Citation) super.clone();
	}
}