package com.demo;

public interface Prototype extends Cloneable{
	
	public Object clone() throws CloneNotSupportedException;

}
