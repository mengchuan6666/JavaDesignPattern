package com.demo2;

import java.awt.Container;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

public class WySpecialtyFacade {
	public static void main(String[] args) {
		JFrame f = new JFrame("���ģʽ: ��Դ�ز�ѡ�����");
		Container cp = f.getContentPane();
		WySpecialty wys = new WySpecialty();
		JScrollPane treeView = new JScrollPane(wys.tree);
		JScrollPane scrollpane = new JScrollPane(wys.label);
		JSplitPane splitpane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true, treeView, scrollpane); //�ָ����
		splitpane.setDividerLocation(230); //����splitpane�ķָ���λ��
		splitpane.setOneTouchExpandable(true); //����splitpane����չ��������                       
		cp.add(splitpane);
		f.setSize(650, 350);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class WySpecialty extends JPanel implements TreeSelectionListener {
	private static final long serialVersionUID = 1L;
	final JTree tree;
	JLabel label;
	private Specialty1 s1 = new Specialty1();
	private Specialty2 s2 = new Specialty2();
	private Specialty3 s3 = new Specialty3();
	private Specialty4 s4 = new Specialty4();
	private Specialty5 s5 = new Specialty5();
	private Specialty6 s6 = new Specialty6();
	private Specialty7 s7 = new Specialty7();
	private Specialty8 s8 = new Specialty8();

	WySpecialty() {
		DefaultMutableTreeNode top = new DefaultMutableTreeNode("��Դ�ز�");
		DefaultMutableTreeNode node1 = null, node2 = null, tempNode = null;
		node1 = new DefaultMutableTreeNode("��Դ�Ĵ��ز����졢�̡��ڡ��ף�");
		tempNode = new DefaultMutableTreeNode("��Դ�ɰ�������");
		node1.add(tempNode);
		tempNode = new DefaultMutableTreeNode("��Դ�̲�");
		node1.add(tempNode);
		tempNode = new DefaultMutableTreeNode("��Դ��β��");
		node1.add(tempNode);
		tempNode = new DefaultMutableTreeNode("��Դ����ѩ��");
		node1.add(tempNode);
		
		
		top.add(node1);
		
		
		node2 = new DefaultMutableTreeNode("��Դ�������ز�");
		tempNode = new DefaultMutableTreeNode("��Դ������");
		node2.add(tempNode);
		tempNode = new DefaultMutableTreeNode("��Դ�����Ӹ�");
		node2.add(tempNode);
		tempNode = new DefaultMutableTreeNode("��Դ������");
		node2.add(tempNode);
		tempNode = new DefaultMutableTreeNode("��Դ�ͼ��");
		node2.add(tempNode);
		top.add(node2);
		tree = new JTree(top);
		tree.addTreeSelectionListener(this);
		label = new JLabel();
	}

	public void valueChanged(TreeSelectionEvent e) {
		if (e.getSource() == tree) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
			if (node == null)
				return;
			if (node.isLeaf()) {
				Object object = node.getUserObject();
				String sele = object.toString();
				label.setText(sele);
				label.setHorizontalTextPosition(JLabel.CENTER);
				label.setVerticalTextPosition(JLabel.BOTTOM);
				sele = sele.substring(2, 4);
				if (sele.equalsIgnoreCase("�ɰ�"))
					label.setIcon(s1);
				else if (sele.equalsIgnoreCase("�̲�"))
					label.setIcon(s2);
				else if (sele.equalsIgnoreCase("��β"))
					label.setIcon(s3);
				else if (sele.equalsIgnoreCase("����"))
					label.setIcon(s4);
				else if (sele.equalsIgnoreCase("����"))
					label.setIcon(s5);
				else if (sele.equalsIgnoreCase("����"))
					label.setIcon(s6);
				else if (sele.equalsIgnoreCase("����"))
					label.setIcon(s7);
				else if (sele.equalsIgnoreCase("�ͼ�"))
					label.setIcon(s8);
				label.setHorizontalAlignment(JLabel.CENTER);
			}
		}
	}
}

class Specialty1 extends ImageIcon {
	private static final long serialVersionUID = 1L;

	Specialty1() {
		super("src/com/demo2/WyImage/Specialty11.jpg");
	}
}

class Specialty2 extends ImageIcon {
	private static final long serialVersionUID = 1L;

	Specialty2() {
		super("src/com/demo2/WyImage/Specialty12.jpg");
	}
}

class Specialty3 extends ImageIcon {
	private static final long serialVersionUID = 1L;

	Specialty3() {
		super("src/com/demo2/WyImage/Specialty13.jpg");
	}
}

class Specialty4 extends ImageIcon {
	private static final long serialVersionUID = 1L;

	Specialty4() {
		super("src/com/demo2/WyImage/Specialty14.jpg");
	}
}

class Specialty5 extends ImageIcon {
	private static final long serialVersionUID = 1L;

	Specialty5() {
		super("src/com/demo2/WyImage/Specialty21.jpg");
	}
}

class Specialty6 extends ImageIcon {
	private static final long serialVersionUID = 1L;

	Specialty6() {
		super("src/com/demo2/WyImage/Specialty22.jpg");
	}
}

class Specialty7 extends ImageIcon {
	private static final long serialVersionUID = 1L;

	Specialty7() {
		super("src/com/demo2/WyImage/Specialty23.jpg");
	}
}

class Specialty8 extends ImageIcon {
	private static final long serialVersionUID = 1L;

	Specialty8() {
		super("src/com/demo2/WyImage/Specialty24.jpg");
	}
}