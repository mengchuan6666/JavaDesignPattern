package com.demo2;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class CookingCommand {
	public static void main(String[] args) {
		Waiter fwy = new Waiter();
		Breakfast changFen = new ChangFen();
		fwy.setChangFen(changFen);
		fwy.chooseChangFen();
		
		Breakfast hunTun = new HunTun();
		fwy.setHunTun(hunTun);
		fwy.chooseHunTun();
		
		
	}
}

//�����ߣ�����Ա
class Waiter {
	private Breakfast changFen, hunTun, heFen;

	public void setChangFen(Breakfast f) {
		changFen = f;
	}

	public void setHunTun(Breakfast f) {
		hunTun = f;
	}

	public void setHeFen(Breakfast f) {
		heFen = f;
	}

	public void chooseChangFen() {
		changFen.cooking();
	}

	public void chooseHunTun() {
		hunTun.cooking();
	}

	public void chooseHeFen() {
		heFen.cooking();
	}
}

//����������
interface Breakfast {
	public abstract void cooking();
}

//�����������
class ChangFen implements Breakfast {
	private ChangFenChef receiver;

	ChangFen() {
		receiver = new ChangFenChef();
	}

	public void cooking() {
		receiver.cooking();
	}
}

//����������
class HunTun implements Breakfast {
	private HunTunChef receiver;

	HunTun() {
		receiver = new HunTunChef();
	}

	public void cooking() {
		receiver.cooking();
	}
}

//��������ӷ�
class HeFen implements Breakfast {
	private HeFenChef receiver;

	HeFen() {
		receiver = new HeFenChef();
	}

	public void cooking() {
		receiver.cooking();
	}
}

//�����ߣ����۳�ʦ
class ChangFenChef extends JFrame {
	private static final long serialVersionUID = 1L;
	JLabel l = new JLabel();

	ChangFenChef() {
		super("�󳦷�");
		l.setIcon(new ImageIcon("src/com/demo2/ChangFen.jpg"));
		this.add(l);
		this.setLocation(30, 30);
		this.pack();
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void cooking() {
		this.setVisible(true);
	}
}

//�����ߣ���⽳�ʦ
class HunTunChef extends JFrame {
	private static final long serialVersionUID = 1L;
	JLabel l = new JLabel();

	HunTunChef() {
		super("�����");
		l.setIcon(new ImageIcon("src/com/demo2/HunTun.jpg"));
		this.add(l);
		this.setLocation(350, 50);
		this.pack();
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void cooking() {
		this.setVisible(true);
	}
}

//�����ߣ��ӷ۳�ʦ
class HeFenChef extends JFrame {
	private static final long serialVersionUID = 1L;
	JLabel l = new JLabel();

	HeFenChef() {
		super("��ӷ�");
		l.setIcon(new ImageIcon("src/com/demo2/HeFen.jpg"));
		this.add(l);
		this.setLocation(200, 280);
		this.pack();
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void cooking() {
		this.setVisible(true);
	}
}